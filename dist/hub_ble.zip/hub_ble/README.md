# MeditationVest BLE v9

BLE name: **MeditationVest**. This firmware adds a saved selection of enabled
channels to the existing exercises and controls. The working GPIO map is unchanged.

| Channel | Pump | Valve | Analog sensor OUT |
|---|---|---|---|
| CH0 | D4 | D17 | D35 |
| CH1 | D23 | D22 | D34 |
| CH2 | D25 | D26 | D32 |
| CH3 | D19 | D18 | VP / GPIO36 |
| CH4 | D16 | D27 | VN / GPIO39 |
| CH5 | D13 | D14 | D33 |

All sensors use 3.3 V and separate ADC1 inputs. Every hub connector uses P4 pump,
P5 valve, P6 unused, P7 analog OUT and P8 3V3. The opposite module connector uses
J1 P5 pump and P4 valve. The user has reported successful hub tests with the same
module/cable on each port. This update does not require rewiring.

## Install

Disconnect the actuator battery physically and keep JP5 open. Upload this sketch
using the classic ESP32 target (`esp32:esp32:esp32`). The user uploads; this release
has not been flashed or physically actuated by the assistant. Reconnect in Bluefy
after upload. Channel selection requires v9; exercises require v8 or newer.
Earlier firmware keeps its supported controls. The current download is v9;
`hub_ble-v8.zip` retains the previous release.

## Enabled channels

Open **Device → Enabled channels**, select the boards in use, then **Apply channels**.
Changes are accepted only when idle. Stop an exercise, test or pattern first.
All six channels are enabled initially; selecting none is allowed and you can
re-enable them from the same settings. Applying a selection never starts outputs.

The ESP32 saves the selection in Preferences/NVS and restores it at startup.
The app reads the hub's selection on connection, including when using another phone.
An unchanged selection does not rewrite flash; a failed save retains the previous
selection. The browser caches the last confirmed selection for offline display only.
Preview settings are separate and never change the hub or its cached selection.

Disabled channels are hidden from zone assignments, sensor displays, channel tests
and linking choices. They remain visible in the Enabled channels picker. Their
outputs stay off, actuator commands are rejected, and analog sampling and per-channel
BLE notifications are skipped. This does not disconnect their wired 3.3 V supply.
Remaining channels keep their normal refresh interval; overall BLE traffic drops.

Saved zone assignments and sensor references are retained when a channel is disabled.
Only enabled members participate in an exercise; a saved pair can run with one
enabled member. A required zone with no enabled member prevents Start until assigned
an enabled channel. Re-enabling restores saved assignments, unless that zone's
assignment was edited while the channel was disabled.

## Four app screens

- **Exercises:** choose Breathing or Body scan, then Start. No settings to edit.
- **Zones:** independent Front / Back view; select a visual zone and assign one
  or two channels. Back zones have distinct assignments. Record sensor references.
- **Sequences:** choose which sequence to configure, select its zone, and edit
  target, pump limit, hold, released interval and zone duration. Choose a round
  count or Until Stop, optional lower back, preparation delay and spoken guidance.
- **Device:** connection options, enabled channels, firmware download, and channel tests,
  individual switches, linked patterns, voltage/ADC readings and charts.

Changing the Zones view or the sequence being edited does not change the exercise
selected on Exercises. Exercise settings are saved locally in the browser;
enabled-channel selection is saved on the hub.

## Percentage targets

For each sensor channel, record **0% with its airbag fully vented**, then inflate
and hold a chosen reference level using the Device test controls and record
**100%**. Reference capture stays available during a manual test or hold, but is
locked during an exercise. Recording a new zero clears that channel's old 100%.
Reference points must be inside ADC endpoints and at least 32 counts apart.

These percentages mean a relative sensor reading, not percentage of air volume,
calibrated pressure, or a safe pressure limit. Recalibrate after moving/replacing
a sensor or materially changing its installation. Calibration is saved for the
selected BLE device in this browser. Preview calibration is separate and never
saved as real hardware calibration. Targets start blank for the user to choose.

The target is `zero + (reference - zero) × targetPercent / 100`, rounded to an ADC
count. Paired channels use their own reference points. Both valves select, then
each pump stops independently when its own averaged raw reading reaches its
target. Both enter the configured hold after the last pump stops, and release
together. Pumps do not top up during hold if the reading falls.

Each pulse has a 100 ms valve lead, maximum pump time 0.05–2 s, hold 0–10 s and
released interval 0.5–10 s. If any target is not reached within the pump limit,
the whole exercise releases and stops, identifying the affected channel. Missing,
stale (500 ms), or ADC-endpoint samples likewise stop sensor-target inflation/hold.
A floating analog input can still look plausible: this is not reliable sensor-
presence detection. Four-sample averaging introduces response delay; physical
overshoot and actual pressure response have not been validated by software tests.

**Timed inflation** is an explicit per-zone alternative. It ignores sensor
feedback, pumps for the configured time, then holds and releases.

## Exercise sequencing

Breathing uses front zone D as a cue for natural breathing awareness, not fixed
inhale/exhale pacing. Body scan uses upper → middle → optional lower back.
Default back durations are 30 s per zone, with 30 s preparation; front defaults
to 5 s preparation and a 30 s window. These are editable testing defaults.

Within each zone, inflate → hold → release repeats. A new pulse starts only if its
complete worst-case duration fits in the remaining zone window. Any final remainder
stays released. At most two channels are assigned to one zone; one zone operates
at a time. These limits do not establish battery/wire current capacity.

The ESP32 owns the sequence and feedback decisions; BLE/UI timing does not control
pump shutdown. Stop, serial `x`, and Bluetooth disconnect end exercises immediately
when handled. No exercise resumes automatically. Delayed controller ticks never
replay missed zones or bursts. Settings commit atomically after every zone has
been validated, and expire if incomplete. Tests/patterns cannot start while an
exercise is settling or released between pulses.

## Channel tests and legacy patterns

Device contains the previous controls, with sensor readings beside each channel.
Manual pump ON expires at 2 s and valve ON at 10 s. Changing one switch does not
renew the other's timer. One test channel at a time; combined tests run one cycle.
States describe commanded outputs, not measured actuator feedback.

Legacy patterns retain independent/paired operation, 1–999 cycles or Until Stop,
pump 0.05–2 s, hold/release 0–10 s, and no cooldown after the final release.
Finite patterns finish after BLE disconnect; continuous patterns finish their
current cycle then release. Tests stop on disconnect. Reconnection never sends
an actuator command. Sensors remain display-only for these legacy controls.

## Connection and audio

First connection requires choosing the device. Automatic reconnection reuses only
the exact previously permitted device ID. Restoration across page reloads depends
on browser support for getDevices; same-page reconnect can reuse its device object.
There is no unrestricted proximity scan or selection by name alone. Explicit
Disconnect, Preview mode, disabled reconnect, and hidden pages suppress retries.
The Connect button remains the fallback for Bluefy. Fresh session validation runs
on each connection and no command or exercise is replayed.

Optional narration uses prepared **ElevenLabs Multilingual v2** clips (Sarah/Lily)
generated once through OpenRouter, with a device-voice fallback and speed selector.
The public app contains audio files, not API credentials or live TTS requests.
Voice prompts run once per zone/round, not every inflation. Stop, disconnect and
page hiding cancel audio, including clips still loading. Background/Bluefy audio
behavior remains device-dependent; text guidance stays visible. Short configured
windows may interrupt a longer prompt at the next zone. Voice quality is subjective.

## Firmware protocol and checks

Protocol2, firmware9, flags255, enabled/analog mask0–63, sensor selector255.
18-byte commands and 20-byte telemetry retain session nonce, sequence, replay and
receive-expiry checks. Opcodes1–4 preserve pattern/stop/manual/exclusive test.
New staged commands: op5 = zone timing (aux index, mask channels, pump max, hold,
release gap, repeats field = zone window); op7 = target counts (pump/hold fields =
first/second channel in ascending order, 0/0 timed mode); op6 = commit (aux kind1/2,
mask stage count, pump field preparation, repeats round count, zero means forever).
Invalid/incomplete configuration never starts outputs. Stop invalidates staging.

Op8 sets the enabled-channel mask (0–63). Aux, pump, hold, release and repeats must
all be zero. It uses the same session, replay and 250 ms receive-expiry checks.
It is rejected during any active output or routine, including preparation and
released intervals. Accepted changes clear staged routines and stale channel/sensor
state; GPIOs are committed off before the flash write. Reply8 means storage failed.
The authoritative mask and command acknowledgement arrive in one summary packet:
byte14 is the mask and byte15 is `0xa9`, replacing the retired digital-sensor age.
Older firmware is decoded separately and does not expose channel selection.

Summary byte19 is active exercise kind1/2, 0 idle, or fault marker
`0x80 | (fault << 3) | channel` (fault1 sensor invalid, fault2 target timeout).
0x30 packets contain kind/phase/step/count, session, round/repeats, phase remaining,
16-bit zone elapsed and 16-bit pulse count. Phases1–6: preparation, valve lead,
inflate, hold, release gap, released remainder. Analog data stays in 0x20 packets.
At most three notifications per 50 ms: summary, alternating exercise/detail, analog.
Disabled channels' detail/analog slots are skipped, not reassigned.
Nominal refresh: exercise100ms, analog channel300ms, debug detail channel600ms.

Native controller/protocol/channel-selection tests and Node model/transport/audio
tests cover these behaviors. The classic ESP32 target compiles with core3.2.1.
Persistence is tested with a storage callback; a real power-cycle restore and
on-device notification reduction have not been physically verified for v9.
Software/simulated checks do not establish physical pressure response or simultaneous
paired-module performance. No assistant upload, BLE hardware connection or actuation.
