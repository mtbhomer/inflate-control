# MeditationVest BLE v7 · six analog channels

Use this package with the six-channel hub pin table. BLE device: **MeditationVest**.

| Channel | Pump | Valve | Analog sensor OUT |
|---|---|---|---|
| CH0 | D4 | D17 | D35 |
| CH1 | D23 | D22 | D34 |
| CH2 | D25 | D26 | D32 |
| CH3 | D19 | D18 | VP / GPIO36 |
| CH4 | D16 | D27 | VN / GPIO39 |
| CH5 | D13 | D14 | D33 |

All sensors use 3.3 V and a separate ADC1 input. Every hub connector uses
**P4 pump / P5 valve**, with P6 unused. Firmware v6 and v7 use CH1's revised actuator
GPIO assignment: **pump D23, valve D22**. Other channel pins are unchanged.

## CH1 wiring and firmware must agree

- Keep the original hub conductors: **D23 / C16 → P4 / A15 pump** and
  **D22 / C15 → P5 / A14 valve**. If you applied the preceding hub-swap proposal,
  restore these endpoints with all power disconnected.
- On the previously working CH1 module, check **L3 / J1 P5 → actual pump-driver
  input**, **M3 / J1 P4 → actual valve-driver input**. If opposite, exchange only
  the M3/L3 command-wire ends; if already correct, do not swap again.
- Keep driver ends, power wiring and the working pump in V1 / valve in P1.
  Standard modules already use J1 P5 for pump and P4 for valve.
- Upload **v7** yourself with battery physically disconnected and JP5 open.
  v5 assigns CH1 D22/D23 oppositely. Verify the complete signal paths and v7
  output timing with actuator power disconnected before a powered test.

This update changes no sensor pin, cycle timing, repeat/link behavior or BLE name.
Module correction and hardware verification are not recorded as completed.

Module printed coordinates are A–X on the solder side; hub coordinates remain
A–X on the component side, USB up.

## Upload and verify

1. Physically disconnect the actuator battery and leave JP5 open.
2. Check every signal lead against the six-channel hub manual, including unused
   P6 contacts. Remove any GPIO connections that conflict with this map.
3. Upload this sketch yourself to the classic ESP32. It compiles for
   `esp32:esp32:esp32`; no assistant upload or actuation has occurred.
4. Open the HTTPS control page in Bluefy, connect to MeditationVest, and compare
   each sensor voltage with a meter. The app supports all six independent inputs.
5. Keep actuator power disconnected for output checks. Run one channel with
   2 seconds pump and 10 seconds hold: its pump GPIO should be high only while
   pumping, its valve through pumping and hold, both low after release.
   Explicitly verify D16/D17 on the received board; their labels are reported,
   but the ESP-32 shield marking does not establish whether they are internally
   reserved. If they fail to switch or the board restarts, do not apply actuator
   power. Resolve the module's pin availability first.
6. Verify local 6 V supplies and test one unworn, vented module at a time.
   Six-channel controls do not establish six-pump battery, fuse or wire capacity.

## Channel tests

The default **Test channels** view tests one channel at a time. Each channel has
its own analog voltage, ADC percentage and graph beside its controls (below on
narrow phones).

- **Test pump + valve**: select the valve for 100 ms, run the pump for the selected
  time, hold for the selected delay, then turn both off. No repeat or fixed cooldown.
- **Pump switch**: independent ON/OFF, automatically OFF after 2 seconds.
- **Valve switch**: independent ON/OFF, automatically OFF after 10 seconds.
- A switch affects only its named output. It does not restart an expired output
  or extend the other output's timer. Readouts report ESP32-commanded states;
  physical pump/valve feedback is not measured.
- Only one test channel can be active. Firmware rejects tests during a pattern,
  other-channel starts during a test, and manual switches during a combined cycle.
- Stop & release and BLE disconnection end test outputs. Reconnect never resumes.

Use **Patterns & links** for the existing independent/linked repeat controls.
Earlier firmware remains usable there, but channel tests require v7. GPIOs remain
exactly as in v6: CH1 pump D23, valve D22; sensor D34.

## Pattern controls

- Pump 0.05–2 seconds; hold and release interval 0–10 seconds.
- Valve lead 100 ms. Pump stops before hold; valve releases after hold.
- One cycle, 1–999 total cycles, or repeat until Stop.
- No fixed delay after the final release. A zero repeat interval does not
  establish physical deflation between cycles.
- Link any two channels with one shared timing command. Unlink restores each
  channel's saved timings. Independent channels have separate state.
- Finite patterns finish after BLE disconnection. Continuous patterns finish
  their current cycle and release; reconnect never starts a pattern.
- Stop & release, or serial `x`, turns all outputs off when received.

## Sensor display

All six ADC1 pins use 12-bit acquisition and ADC_11db attenuation. Four raw/
millivolt sample pairs are averaged; Arduino performs separate conversions for
these APIs. Output is volts, a 30-second chart, ADC range percentage and limit
indicators. It is not calibrated pressure or inflation. A floating input can
still produce a reading. Sensor data is display-only; no pressure cutoff.

The control task owns GPIO and runs separately from BLE and sensor acquisition.
Three notifications are sent per 50 ms: summary, one channel detail, one analog
packet. Each channel refreshes nominally every 300 ms; physical BLE performance
and six-channel hardware timing remain to be checked. Stale values are blanked.

## Protocol

Service `8d5a0001-4c7b-4f45-9d68-8e0c2c970001`; command/status/info use 0002,
0003/0004 respectively. Protocol version 2, firmware revision 7, enabled mask63,
analog mask63, sensor selector255. Fixed 20-byte summary/detail/analog packets
retain channel identity and session nonce. Commands are 18 bytes, sequenced,
serialized and session-checked. Stop bypasses the normal command queue.

Firmware v7 advertises flags63. Opcodes: 1 pattern, 2 stop, 3 manual output,
4 exclusive test cycle. Opcode3 uses the pump/hold fields as 0=OFF, 1=ON,
2=unchanged, with release/repeats=0; the mask must contain one enabled channel.
Opcode4 uses ordinary pump/hold durations, release0/repeats1, one channel.
All non-stop commands retain session, sequence and 250 ms receive-expiry checks.
Phase5 is manual testing. In v7 control summaries, the previously unused raw
field holds 12 output bits (pump then valve for each channel); flags0 and age65535.
This lets one summary atomically acknowledge a command and report all output
states. Analog values continue in separate channel-labelled 0x20 packets.

## Checks

`clang++ -std=c++17 -Wall -Wextra -pedantic firmware/tests/hub_ble_test.cpp -o /tmp/hub-ble-test`
then `/tmp/hub-ble-test`; compile with Arduino-ESP32 core3.2.1.
Software checks do not establish physical pin, pressure or power validation.

[Espressif GPIO reference](https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-reference/peripherals/gpio.html)
